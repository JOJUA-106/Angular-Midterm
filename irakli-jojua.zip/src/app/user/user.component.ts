import { CommonModule } from '@angular/common';
import { ChildUser, ParentUser } from './../types';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DisplayService } from '../services/display.service';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent implements OnInit {
  @Input() parentUsers: ParentUser[] = [];
  @Output() parentFunction: EventEmitter<any> = new EventEmitter();

  constructor(private displayService: DisplayService) {}

  printUsers(): void {
    this.displayService.displayArray(this.parentUsers);
  }

  ngOnInit(): void {
    this.parentFunction.emit(this.childUsers);
  }

  childUsers: ChildUser[] = [
    {
      Id: 1,
      Firstname: 'ალექსანდრე',
      Lastname: 'აბაშიძე',
      DateOfBirth: '2006-04-12',
      PhoneNumber: '598-12-34-56',
      Email: 'alexandre@gmail.com',
    },
    {
      Id: 2,
      Firstname: 'მარიკა',
      Lastname: 'ქარჩავა',
      DateOfBirth: '1990-11-09',
      PhoneNumber: '598-65-43-21',
      Email: 'marika@gmail.com',
    },
    {
      Id: 3,
      Firstname: 'გიორგი',
      Lastname: 'კვანტალიანი',
      DateOfBirth: '1999-02-20',
      PhoneNumber: '598-98-76-54',
      Email: 'giorgi@gmail.com',
    },
    {
      Id: 4,
      Firstname: 'ნინო',
      Lastname: 'კიკნაძე',
      DateOfBirth: '1995-06-30',
      PhoneNumber: '598-32-14-56',
      Email: 'nino@gmail.com',
    },
  ];
}
