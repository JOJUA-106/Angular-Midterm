import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ChildUser, ParentUser, User, UserI } from './types';
import { CommonModule } from '@angular/common';
import { UserComponent } from './user/user.component';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, UserComponent, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title: string = 'ირაკლი ჯოჯუა';

  registrationForm = new FormGroup({
    Firstname: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
    ]),
    Lastname: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
    ]),
    PhoneNumber: new FormControl('', [
      Validators.required,
      Validators.minLength(9),
    ]),
    Email: new FormControl('', [
      Validators.required,
      Validators.email,
      Validators.minLength(8),
    ]),
    DateOfBirth: new FormControl('', [Validators.required]),
  });

  users: UserI[] = [
    {
      firstName: 'Irakli',
      lastName: 'Jojua',
      age: 20,
    },
    {
      firstName: 'Giorgi',
      lastName: 'merebashvili',
      age: 25,
    },
    {
      firstName: 'Nika',
      lastName: 'kvaracxelia',
      age: 31,
    },
    {
      firstName: 'Ana',
      lastName: 'metreveli',
      age: 19,
    },
    {
      firstName: 'Mariam',
      lastName: 'Metreveli',
      age: 21,
    },
  ];

  parentUsers: ParentUser[] = [
    {
      Id: 1,
      Firstname: 'ნიკა',
      Lastname: 'ჯაფარიძე',
      DateOfBirth: '2001-05-15',
      PhoneNumber: '599-12-34-56',
      Email: 'nika@gmail.com',
    },
    {
      Id: 2,
      Firstname: 'თამარ',
      Lastname: 'ბექაური',
      DateOfBirth: '2004-10-22',
      PhoneNumber: '599-65-43-21',
      Email: 'tamari@gmail.com',
    },
    {
      Id: 3,
      Firstname: 'მარიამ',
      Lastname: 'გიორგაძე',
      DateOfBirth: '2000-03-30',
      PhoneNumber: '599-98-76-54',
      Email: 'mariami@gmail.com',
    },
  ];

  childUsers: ChildUser[] = [];

  parentFunction(data: ChildUser[]) {
    this.childUsers = data;
  }

  addUser(user: any) {
    const newUser: any = {
      Id: this.parentUsers[this.parentUsers.length - 1].Id + 1,
      ...user,
    };
    this.parentUsers = [...this.parentUsers, newUser];
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      this.addUser(this.registrationForm.value);
      this.registrationForm.reset(); // Optional: Reset the form after submission
    }
  }
}
